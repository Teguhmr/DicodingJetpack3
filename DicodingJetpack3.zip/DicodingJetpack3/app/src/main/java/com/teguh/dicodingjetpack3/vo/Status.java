package com.teguh.dicodingjetpack3.vo;

public enum Status {
	SUCCESS,
	ERROR,
	LOADING
}
