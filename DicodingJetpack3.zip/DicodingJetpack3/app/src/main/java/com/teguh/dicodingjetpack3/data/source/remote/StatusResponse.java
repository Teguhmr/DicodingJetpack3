package com.teguh.dicodingjetpack3.data.source.remote;

public enum StatusResponse {
	SUCCESS,
	EMPTY,
	ERROR
}
