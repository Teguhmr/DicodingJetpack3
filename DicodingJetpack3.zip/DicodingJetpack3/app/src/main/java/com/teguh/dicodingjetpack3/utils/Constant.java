package com.teguh.dicodingjetpack3.utils;

public class Constant {
	public static final String DISCOVER_MOVIE_URL = "https://api.themoviedb.org/3/movie/now_playing?api_key=";
	public static final String DISCOVER_TV_URL = "https://api.themoviedb.org/3/tv/popular?api_key=";
	public static final String IMAGE_URL = "https://www.themoviedb.org/t/p/w440_and_h660_face";
}
